import React from "react";

export const AppIcon: React.FC = () => {
  return (
    <svg
      xmlns="http://www.w3.org/2000/svg"
      width="24"
      height="24"
      viewBox="0 0 16 16"
      fill="none"
    >
      <path
        fill="currentColor"
        fill-rule="evenodd"
        d="m14.979 15.361-.178.238a1 1 0 0 1-1.602 0L12 13.995l-1.2 1.604a1 1 0 0 1-1.6 0L8 13.995l-1.2 1.604a1 1 0 0 1-1.6 0L4 13.995l-1.2 1.604a1 1 0 0 1-1.6 0l-.178-.238A3.027 3.027 0 0 1 1 15V7a7 7 0 1 1 14 0v8c0 .122-.007.243-.021.361zM7 4.5a1.5 1.5 0 1 1-3 0 1.5 1.5 0 0 1 3 0zM10.5 6a1.5 1.5 0 1 0 0-3 1.5 1.5 0 0 0 0 3z"
        clip-rule="evenodd"
      />
    </svg>
  );
};
